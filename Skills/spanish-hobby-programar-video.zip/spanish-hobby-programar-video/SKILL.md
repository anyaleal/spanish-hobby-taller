---
name: spanish-hobby-programar-video
description: Programa en Metricool los reels o videos de Spanish Hobby (TikTok, Instagram, YouTube, Facebook) cuando Anya pida agendar, programar o publicar un reel o un video. Genera todos los textos de cada red y lo agenda. No usar para artículos del sitio ni para textos de la literatura.
---

# Programar video · Spanish Hobby

Agenda en **Metricool** un reel o video ya producido, en las cuatro redes de Spanish Hobby. El video vive en Google Drive; Metricool lo toma de ahí y lo distribuye solo al llegar la fecha. Esta skill genera todos los textos, propone el nombre del archivo, y agenda. No produce el video.

**Método real (probado en la prueba de ruta, 14 ago 2026):** el video sale de la carpeta **Reels** de Google Drive, se pasa a Metricool por **enlace de compartir**, y todo queda dentro del planificador de Metricool. No se sube nada nativo a YouTube ni a ninguna red.

---

## Antes de nada: gotcha de Metricool

El conector de Metricool **no se activa solo**. Anya debe encenderlo con el menú **"+"** del chat cada sesión. Si las tools de Metricool no responden, para y pídele que lo active antes de seguir.

---

## Constantes (no preguntar, ya están decididas)

- **Marca:** Spanish Hobby, `brandId 5089146`, timezone `America/Chicago`. **NUNCA** Anya Literal (5309582). Confírmalo con `getBrandSettings` al inicio.
- **Redes:** TikTok, Instagram, YouTube, Facebook. Las cuatro, siempre.
- **Carpeta origen:** **Reels** en Google Drive. Siempre. No preguntes cuál es.
- **Acceso al video:** enlace de compartir de Drive con permiso "cualquiera con el enlace". Es la vía probada.
- **Idioma del copy:** inglés. Siempre.
- **Voz:** editorial y seria (NYT, Audible). Curiosidad más alivio. Sin hype, sin urgencia, sin emojis, sin tono de app de idiomas.
- **Cero rayas largas** en cualquier texto (se leen muy "IA" y rompen el puente con el español). Usa el signo que mejor le caiga a cada frase: coma, punto y seguido, punto y coma, dos puntos o paréntesis. No uno solo por defecto.
- **Playlist:** ninguna, salvo que Anya lo pida.

---

## Paso 0 — Intake

1. **¿Individual o lote?** Pregúntale a Anya si es un video o varios. Un solo flujo sirve para los dos.
2. **Por cada video, pide el guion.** El nombre del archivo lo propones tú (ver abajo), no se lo pidas.
3. **Confirma la marca** con `getBrandSettings`: que sea 5089146 antes de tocar nada.

---

## Nombre del archivo (uno por video, desde el guion)

Los videos salen del dispositivo con nombre automático (`IMG_4827.mov`). Hay que renombrarlos.

- Con el guion, **propón un nombre**: inglés, minúsculas, con guiones, palabra clave del tema al inicio, con la extensión del archivo. Ejemplo de formato: `ser-estar-map.mp4`. Es un nombre distinto por video, derivado de su guion.
- Muéstraselo y **espera a que Anya confirme** que ya renombró el video en la carpeta Reels de Drive y te pase el **enlace de compartir**.

---

## Qué generar por video (todo en inglés)

- **TÍTULO:** máx 100 caracteres, palabra clave al inicio, sin clickbait.
- **TÍTULO DE TIKTOK:** TikTok exige un campo de título propio, aparte del texto del post. Sácalo del gancho, corto. (Si no se pone, TikTok no agenda.)
- **DESCRIPCIÓN YOUTUBE:** 3 a 5 párrafos. El primero con la palabra clave. El último invita a explorar el método gratis en SpanishHobby.com y a reservar clase gratuita en `calendly.com/hola-spanishhobby/30min`.
- **DESCRIPCIÓN CORTA (TikTok e Instagram):** máx 150 caracteres, gancho directo más palabra clave.
- **HASHTAGS:** 15, mezcla de nicho, audiencia, tendencia y marca (`#SpanishHobby` `#TheSpanishMap`).
- **ETIQUETAS YOUTUBE:** 10 a 15, separadas por comas.

**Ajustes fijos:**

- YouTube: Categoría **Education**, Privacidad **Public**, Audiencia **Not made for kids**, formato **Short**.
- Instagram: **Reel**. Formato general: vertical, menos de 30 segundos.
- **Carátula:** el primer cuadro del video. No configures portada aparte.

---

## Fecha y hora

- Cada reel es **diario**: uno por día calendario.
- **Por defecto** (Anya no da fecha): revisa la planificación con `getScheduledPosts` y agenda el **próximo día libre** (el siguiente día sin ningún reel programado). Consulta el mejor horario con `getBestTimeToPostByNetwork` y úsalo por red.
- **TikTok no tiene analíticas todavía:** elige la hora que consideres más apropiada (horario general por industria para contenido educativo). Esto es lo esperado, no un fallo.
- **En lote:** encadena, cada video al siguiente día libre consecutivo.
- **Solo si Anya da día u hora específicos**, usa esos en vez del automático.

---

## Flujo de aprobación (dos fases)

### Fase 1 — Muestra y espera
Antes de agendar nada, por cada video muéstrale a Anya: nombre del archivo, todos los textos, hashtags, etiquetas, y el plan de **fecha y hora por red**. Cierra con **"¿Apruebas?"**. No agendes sin aprobación explícita.

### Fase 2 — Agendar (solo tras la aprobación)
- Agenda **cada red por separado** para que cada una quede a su hora exacta (`createScheduledPost`).
- Toma el video del enlace de Drive. **Autopublicación activada.**
- Confírmale a Anya el nombre, la fecha y la hora que quedó en cada red.

---

## Verificación

- **Estado esperado: `Pending`.** Significa programado y esperando su hora. No falta nada, es lo normal.
- Si alguna red sale **`Sent`** (solo IG y TikTok): quedó sin autopublicación, o sea publicación manual. Avísale a Anya para que lo corrija (duplicar el post y activar autopublish).
- Si sale **`With errors`**: abre el detalle y repórtale el error.

---

## Mejora futura (no ahora)

Cuando TikTok reporte analíticas y haya más volumen de datos, añade un paso previo: consultar en Metricool las publicaciones de mejor rendimiento y ajustar temas y hashtags hacia ese patrón. Hoy los datos son pocos y con hueco en TikTok, así que los hashtags van fijos por estrategia, no "optimizados", para no ensuciar la lectura de qué funciona.
