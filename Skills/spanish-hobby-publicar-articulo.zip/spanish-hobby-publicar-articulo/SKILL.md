---
name: spanish-hobby-publicar-articulo
description: Publica o actualiza en WordPress un artículo ya escrito de SpanishHobby.com cuando Anya pida subirlo, publicarlo o actualizarlo. No usar para escribir el artículo ni para textos de la literatura.
---

# Publicar artículo · Spanish Hobby

Sube a WordPress (Avada + Yoast) un artículo **ya escrito**. Escribir es otra cosa: eso vive en Cowork con `spanish-hobby-escribir-articulo`. Esta skill solo publica.

**Método real (probado en la sesión de sintaxis / semántica / pragmática):** todo se hace con `fetch()` de **mismo origen desde el navegador integrado de Claude Code**, no desde la terminal. `curl` y Node dan 403 por Cloudflare; el navegador integrado, al cargar `https://spanishhobby.com/`, resuelve el managed challenge de forma pasiva (sin CAPTCHA) y hereda la cookie `cf_clearance`. La autenticación con WordPress es **Basic Auth con Application Password** (`AnyaLiteral`), usada solo en memoria. Anya no toca ningún navegador: lo único manual suyo es pegar el Application Password al inicio, y los pasos que la API no cubre (301, purga de caché, imágenes).

Doc de referencia con los valores exactos: `plantilla-tecnica.md` (carpeta `Contenido página web`). Léelo antes de tocar nada. Si algo de esa doc contradice lo de aquí, gana lo de aquí: esto es lo que de verdad funcionó (ver "Taxonomía plana").

---

## Paso 0 — Intake

1. **¿Nuevo o actualización?** Localiza por slug: `GET /wp-json/wp/v2/posts?slug=<slug>&context=edit`. Existe → `PUT /posts/{id}`. No existe → `POST /posts`. No dupliques.
2. **El archivo `.md`:** cuerpo + bloque de metadatos (título, slug, categoría, keyphrase, SEO title, meta desc, imagen).
3. **Application Password** de `AnyaLiteral`. En memoria, nunca a disco.
4. **Verifica la conexión:** `GET /wp-json/wp/v2/users/me?context=edit` → 200 antes de nada.

---

## Categorías — taxonomía PLANA

Esto corrige el modelo "pilar anidado" de la doc vieja: en este sitio la taxonomía es **plana** (todas `parent:0`). Un post lleva la categoría de su tema **más** el pilar, como dos IDs sueltos: semántica = `[52, 43]`, pragmática = `[53, 43]`.

- Lista siempre con `GET /wp-json/wp/v2/categories?per_page=100&context=edit&_fields=id,name,slug,parent,count`. (`?parent=43` viene vacío: no hay jerarquía.)
- IDs confirmados: Hidden Structure **43**, Phonetics **49**, Morphology **44**, Syntax **45**, Semantics **52**, Pragmatics **53**.
- **Building Blocks** y **Real World Spanish**: sus IDs de pilar y de tema aún no están verificados. Sácalos con el GET antes de publicar un artículo de esos pilares.
- Si la categoría del tema **no existe**, **para y avísale a Anya.** No la crees por tu cuenta. (En la sesión pasada sí se crearon Semantics/Pragmatics, pero solo tras preguntar.)

---

## Ensamblado del `content`

- Estructura: `WRAP_OPEN` (contenedor + row + column + `[fusion_text]`) + cuerpo HTML limpio + CTA + cierre del wrapper + `[fusion_global id="222"]`.
- Cuerpo: **sin H1**, párrafos desnudos, `<h2>` para secciones, tablas HTML estándar `<table><tbody><tr><th>/<td>`, español en `<em>`, término técnico en `<strong>`. Nada de shortcodes de tabla de Fusion.
- Wrapper de referencia: **morphology (ID 6319)**.
- **CTA: cópialo byte a byte de `/spanish-nouns/` (ID 5753).** Gotcha real: en 5753 el `<div>` del CTA vive **fuera** del wrapper (después de `[/fusion_builder_container]`), no dentro como en morphology. No lo cortes asumiendo que está dentro: lee la cola cruda (`content.raw`) y copia los bytes literales. Colócalo como en morphology pero con los bytes de 5753. Nunca lo reescribas de memoria.

---

## Flujo de dos fases

### Fase 1 — Reconocimiento (solo lectura, no escribe nada)
Muéstrale a Anya, para aprobar: los campos finales (`title`, `slug`, `status`, `categories`, `content` ensamblado, `excerpt` = metadesc, los tres `_yoast_wpseo_*`), si es POST o PUT y sobre qué ID, si el slug cambia (y el slug viejo para el 301), y si la imagen existe o no. Cierra preguntando **"¿OK, ejecuta?"**. No sigas sin esa confirmación.

### Fase 2 — Ejecución (solo tras "OK, ejecuta")
- **POST nuevo:** `title, slug, status:'publish', content, excerpt(=metadesc), categories:[tema, 43], meta:{_yoast_wpseo_title, _yoast_wpseo_metadesc, _yoast_wpseo_focuskw}`. Sin `featured_media` salvo que la imagen exista y Anya lo confirme.
- **PUT existente:** `title, content, excerpt(=metadesc), meta:{…}`. Envía `slug` / `categories` / `featured_media` **solo si cambian**.
- **`excerpt` == `_yoast_wpseo_metadesc`, palabra por palabra, en el MISMO request. Nunca vacío** (si queda vacío se desbordan las tarjetas del pilar).
- **Imágenes intactas** salvo permiso explícito. En `/media`, solo GET; no subas nada por tu cuenta.

### Verificación (siempre)
- `GET /posts/{id}?context=edit` **crudo**: confirma title, slug, status, categories, que `excerpt.raw === meta._yoast_wpseo_metadesc`, y que el `content` termina en `[fusion_global id="222"]`.
- `fetch` del HTML público: confirma que no aparecen `[fusion_` crudos. Si sigue mostrando lo viejo, es **caché, no fallo**: la fuente de verdad es el GET a la API, no el HTML.

---

## Cierre: lo que Anya hace a mano

No purgues ni redirijas tú. Devuélvele IDs / URLs / slug viejo y recuérdale:

1. **301** si cambió el slug.
2. **Purga de caché**, en orden: Avada (Options → Performance) → Bluehost (Caching → Purge) → Cloudflare (solo si tras 1 y 2 sigue rancio, vía soporte/panel de Bluehost, no desde su cuenta de Cloudflare).
3. **Imagen destacada** si el tema no tenía.
4. Botón del pilar / Fase 3 del pilar, si aplica.
