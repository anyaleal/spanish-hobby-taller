---
name: spanish-hobby-guiones-de-articulo
description: Genera guiones de video corto (reels, TikTok, YouTube Shorts) para Spanish Hobby a partir de un artículo publicado de SpanishHobby.com, cuando Anya pase el link de un artículo y pida los guiones. Devuelve un menú para escoger y luego los guiones elegidos en inglés y español, listos para subtitular en CapCut. No usar para escribir el artículo, ni para programar el video, ni para textos de la literatura.
---

# Guiones de video Spanish Hobby (a partir de un artículo)

De un artículo ya publicado en SpanishHobby.com, saca los guiones de video corto listos para grabar y subtitular.
El artículo es la fuente de verdad. El guion nunca inventa contenido nuevo: traduce a voz hablada lo que el artículo ya enseña.

**Para qué sirven estos guiones.** Anya los usa como subtítulos en CapCut. Cada video lleva **dos pistas de subtítulo apiladas**: arriba el inglés (la principal, porque el público es angloparlante) y debajo, más pequeño, el español. Por eso el guion se entrega en los dos idiomas y la traducción tiene que **calzar línea por línea** con el inglés (ver la regla de traducción abajo).

**Tu rol aquí.** En esta tarea eres el experto en contenido para social media y SEO. Anya te delega la decisión creativa: tú lees el artículo, sacas los ángulos, y para cada guion **eliges el gancho que mejor le calza**. Le entregas un menú resuelto para que ella escoja; no le devuelves la decisión pregunta por pregunta.

**Idioma.** El guion base va en **inglés**, primera persona, hablado y natural. El español aparece dentro del guion solo como ejemplo de idioma. La versión en español (para el subtítulo de abajo) es una traducción fiel, no un guion distinto.

**Alcance.** Solo Spanish Hobby (la academia). Si el pedido es de la literatura, o para programar/publicar el video, esta skill no aplica.

---

## El flujo tiene dos momentos

**Momento 1: el menú.** Le das a Anya un menú de guiones en inglés (mínimo 10) para que escoja.
**Momento 2: los elegidos.** Cuando Anya dice cuáles quiere ("el 1, el 3, el 7..."), le entregas esos, cada uno en inglés y luego en español, intercalados.

No adelantes el español en el momento 1. El español se produce solo para los guiones que ella escoja.

---

## Paso 1 — Leer el artículo

Toma el link que dio Anya y lee el artículo completo (fetch). Si no hay link pero sí un tema, avísale que esta skill parte del artículo publicado y pregúntale si quiere que trabajes desde el tema igual.

De la lectura saca: el concepto central y su lugar en el mapa; cada error o tropiezo concreto del angloparlante; y los ejemplos en español que el artículo ya usa (reúsalos, no inventes otros).

---

## Paso 2 — El menú (mínimo 10 guiones)

Un ángulo = un error, contraste o revelación **concreta y cotidiana**, enfocado para caber en menos de 30 segundos. No un tema entero, una sola pieza.

**Entrega mínimo 10 guiones completos en inglés**, numerados, para que Anya escoja siete (uno por día de la semana). Si el artículo da para más de 10 ángulos fuertes, dale un poco más. Si de verdad no llega a 10 ángulos buenos, entrega los que haya y dilo con claridad: no rellenes con ángulos flojos o repetidos solo para llegar al número.

Ordena el menú del gancho más fuerte al menos fuerte.

En este momento cada guion va así:

```
## [N]. [Título corto]
Caja del mapa: [Hidden Structure / Building Blocks / Real World Spanish] ([subtema])
Gancho: [tipo de gancho elegido]

[Guion en inglés, 50-80 palabras]
```

Cierra el menú invitando a Anya a decir cuáles quiere.

---

## Paso 3 — Los elegidos (inglés + español intercalados)

Cuando Anya diga cuáles escoge, entrega **solo esos**, en este orden exacto:

```
## [N]. [Título corto]

EN:
[Guion en inglés]

ES:
[Traducción fiel al español]
```

Primero el guion 1 en inglés e inmediatamente su español, después el guion 2 en inglés y su español, y así. **Nunca** todos los ingleses juntos y luego todos los españoles: Anya los copia de a pares a CapCut.

---

## Regla de traducción (crítica para el subtítulo)

El español va debajo del inglés, apilado, en el mismo video. Las dos pistas tienen que verse paralelas. Por eso:

- **Respeta la puntuación del inglés.** Las comas, los puntos, los dos puntos y el punto y coma van donde están en el inglés. Mismo número de frases, mismos cortes.
- **Fiel, no literal.** Traduce el sentido en español natural, pero conservando el ritmo y la estructura de frases del original. Si el inglés remata con dos puntos y una lista, el español remata igual.
- **Única divergencia permitida:** los signos de apertura del español (¿ y ¡) son obligatorios y se agregan aunque el inglés no los tenga. Eso es ortografía correcta, no rompe el paralelo.
- **Sin rayas largas** tampoco en español (regla de marca, aplica a los dos idiomas).
- **Los ejemplos en español se quedan igual.** Si el guion en inglés cita *vaca*, *vino*, *pero*, *perro*, en la traducción esas palabras no cambian: son el ejemplo, no la narración.
- El español es **traducción del mismo video para angloparlantes**, no un guion re-enganchado para público hispanohablante. No cambies la puerta de entrada ni adaptes el error: solo traduce.

---

## Paso previo invisible — Elegir el gancho de cada guion

Cada guion entra por algo concreto, nunca por teoría, pero **la puerta varía**. Menú de ganchos:

1. **La corrección.** "Stop saying the Spanish v like the English one." Directa. Con medida.
2. **El reconocimiento.** "You already own the hard Spanish r." Entra por algo que ya hace bien. Alivio, no regaño.
3. **La pregunta.** "Why does *perro* mean dog but *pero* means but?" Abre un bucle que el cuerpo cierra.
4. **El dato que sorprende.** "Spanish spelling never lies." Una afirmación que intriga.
5. **La mini escena / demo.** "Hold a sheet of paper in front of your lips and say 'paper.'" El espectador hace algo físico.
6. **El mito derribado.** "Everyone tells you the r is the hard part. It isn't." Contradice lo que ya le dijeron.
7. **El momento reconocible.** "You're mid-sentence in Spanish, and your brain just stalls." Nombra una experiencia, no una regla.

**Regla de variedad (clave).** En el menú, ningún tipo de gancho domina. No más de dos guiones con la misma puerta. Nada de diez "Stop..." seguidos: el imperativo repetido empuja al tono de app que la marca rechaza, y aburre. Elige el gancho por encaje: un error de pronunciación pide corrección o demo; un dato de ortografía pide el dato que sorprende; algo que el angloparlante ya sabe pide el reconocimiento.

---

## El molde de cada guion

- **Menos de 30 segundos. 50 a 80 palabras.** Cuéntalas. Si se pasa, recorta.
- **Inglés hablado, primera persona.** Como si Anya lo dijera a cámara.
- **Entra por lo concreto** (el gancho elegido), nunca por la definición ni la teoría.
- **Cuerpo de 4 a 6 líneas.** Cuando compara inglés y español, los dos lados van en la misma frase. Nunca solo un lado.
- **Cierra en beneficio o revelación.** El remate aterriza en lo que el espectador gana. **No etiqueta la caja del mapa.** El puente al mapa se queda en el artículo, no en el video de menos de 30 segundos.

---

## Reglas de marca (filtran todo)

- **Sin rayas largas (em-dash).** Nunca, en ningún idioma. Coma, punto, punto y coma, dos puntos o paréntesis. Los dos puntos son el signo de la casa.
- **Sin emojis. Sin hype, urgencia, tono de gurú ni de app.** Registro editorial: NYT, Audible, MasterClass.
- **Sin testimonios inventados ni promesas de tiempo** ("fluent in 2 weeks").
- **Taxonomía de marca:** "determiner", no "article".
- **Frases-firma disponibles** (con naturalidad, no forzadas): "Pro tip:", "Think of Spanish like...", "learn phrases, not pieces", "connection, not perfection", "treat Spanish like a hobby", "real world Spanish".
- **La marca no es Anya.** El guion habla del idioma. Si hay CTA a clase, es "a Spanish Hobby teacher", nunca Anya por nombre.

---

## Checklist antes de entregar

Menú (Momento 1):
- [ ] Salí del artículo publicado, no inventé contenido nuevo
- [ ] Reusé los ejemplos en español del propio artículo
- [ ] Mínimo 10 guiones (o el número real de ángulos fuertes, dicho con claridad)
- [ ] Ordenados del gancho más fuerte al menos fuerte
- [ ] Ganchos variados: ningún tipo se repite más de dos veces
- [ ] Cada guion entra por lo concreto y cierra en beneficio, sin etiquetar la caja del mapa
- [ ] 50 a 80 palabras cada uno
- [ ] Cero rayas largas, cero emojis, cero hype; "determiner", no "article"
- [ ] Invité a Anya a escoger

Elegidos (Momento 2):
- [ ] Solo los guiones que Anya escogió
- [ ] Intercalados: inglés y luego español, guion por guion (no todos los ingleses juntos)
- [ ] La traducción respeta la puntuación del inglés (mismas comas, puntos, dos puntos, mismo número de frases)
- [ ] Se agregaron ¿ y ¡ donde el español los exige
- [ ] Los ejemplos en español quedaron iguales en las dos versiones
