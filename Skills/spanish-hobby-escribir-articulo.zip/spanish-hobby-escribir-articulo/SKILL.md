---
name: spanish-hobby-escribir-articulo
description: Escribe un artículo en inglés para SpanishHobby.com cuando Anya pida redactar un artículo del sitio sobre un tema del español. No usar para la literatura ni para textos en español.
---

# Artículo Spanish Hobby

Escribe un artículo del sitio SpanishHobby.com siguiendo el estándar editorial de la marca.
El estándar de referencia es el artículo publicado `/spanish-morphology/`. Si dudas de un valor, ese es el patrón.

**Idioma:** el artículo va en **inglés**, siempre. El español aparece solo como ejemplo de idioma, en cursiva.
**Extensión objetivo:** 1.200 a 1.600 palabras.
**Alcance:** esta skill es solo para la academia (Spanish Hobby). Si el pedido es de la página de literatura o pide un texto en español, no apliques esta skill.

---

## Paso 0 — Intake (antes de escribir una sola línea)

No empieces el artículo hasta tener esto claro. Preséntaselo a Anya en pocas líneas y espera su OK (o procede si ella dice que avances):

1. **Tema exacto.** Qué tema del español cubre el artículo.
2. **Material de referencia.** Pregunta: "¿Tienes un link o contenido de referencia, o lo escribo desde el mapa?"
   - Si da un link o contenido: úsalo como fuente principal.
   - Si no: escríbelo desde El Mapa del Español y tu conocimiento del idioma.
3. **Las tres preguntas** (respóndelas tú en una frase cada una y confirma con Anya):
   - ¿Dónde vive este tema en el mapa? (Hidden Structure, Building Blocks o Real World Spanish, y en qué punto exacto)
   - ¿Qué cosa concreta le pasa al angloparlante con este tema? (el tropiezo real, no la definición)
   - ¿Con qué otra parte del mapa se conecta? (todo artículo tiende un puente hacia otra capa al menos una vez)

Solo cuando estas tres estén respondidas, empieza a escribir.

---

## Estructura, sección por sección

### 1. Apertura en frío (2 a 4 párrafos, sin encabezado)
Nunca empieces con "In this article we will learn about...". Nunca definas primero.
Empieza con una afirmación concreta y un ejemplo inmediato: el lector debe ver el fenómeno antes de saber cómo se llama. Solo después nombras el concepto y lo ubicas en el mapa. Cierra la apertura con la promesa: qué va a entender el lector que hoy no entiende.

### 2. El concepto central (H2)
Aquí introduces la terminología real, sin esconderla. Reglas:
- La palabra técnica va en **negrita** la primera vez.
- Se define en una sola frase, en inglés llano.
- Se acompaña de un ejemplo desarmado pieza por pieza.
- Se compara con el inglés siempre: el lector piensa en inglés, úsalo como puente, no como enemigo.

### 3. Secciones de desarrollo (2 a 4 H2)
Cada una desarrolla una faceta del concepto y lleva **al menos una tabla**.
Tabla estándar: 2 o 3 columnas, encabezados cortos, 4 a 6 filas (nunca más de 6). El español en cursiva.

### 4. El puente entre capas (dentro de una sección, no aparte)
En algún punto el artículo demuestra que el mapa está conectado. Un párrafo basta: muestra cómo una capa "entrega" al lector a otra (por ejemplo, morfología hacia pragmática). Esto es lo que hace que el artículo sea de Spanish Hobby y no de cualquier blog de gramática.

### 5. What English speakers usually get wrong (H2)
Encabezado fijo o variante muy cercana. Es la sección que la gente comparte.
- Entre 4 y 6 errores, reales y observados en clase, no hipotéticos.
- Cada uno empieza con una frase corta en negrita que nombra el error, y luego la explicación.
- Si nombras un hábito del inglés, muéstralo con un ejemplo en inglés en esa misma frase.
- En todo contraste entre los dos idiomas aparecen los dos lados. Nunca solo el inglés, nunca solo el español.

### 6. Try it yourself (H2)
Mini-práctica corta, sin solucionario: un ejercicio de reconocimiento y uno de producción. Cierra con una frase que reencuadre lo que el lector acaba de hacer.

### 7. Where this sits on the map (H2)
Encabezado fijo. Dos párrafos: primero la ubicación literal (qué hay debajo, encima o al lado); segundo el valor práctico (qué gana el estudiante por haber entendido esto). La última frase siempre aterriza en el mapa.

### 8. Bloque CTA
Se copia tal cual desde `/spanish-nouns/`. No se reescribe ni se improvisa. (El detalle exacto vive en `plantilla-tecnica.md`; la publicación es un paso aparte.)

---

## Voz

- **Segunda persona.** "You", no "the learner", no "one".
- **Frases cortas, verbos claros.** Si una frase necesita tres comas para respirar, pártela.
- **Dos puntos, no rayas.** Los dos puntos introducen el ejemplo, la aclaración, el remate.
- **Pocas contracciones.** "You cannot", "it does not": peso de manual serio sin rigidez.
- **El español siempre en cursiva**, sin excepción.
- **Cero relleno** ("It's important to note that", "Let's dive in", "As we mentioned earlier").
- **Cero condescendencia.** No se promete que algo es fácil: se promete que es entendible.
- **Sin emojis, sin exclamaciones** (salvo cuando el ejemplo lo exija: *¡Ay!*).
- **La marca no es Anya.** El artículo habla del idioma, no de la autora. Única excepción: el CTA.

---

## Marcado del ejemplo citado (specimen)

Cuando el texto señala una frase concreta y habla *de* ella, esa frase es un specimen y debe verse distinta del cuerpo.

| Qué es | Cómo se marca | Ejemplo |
| --- | --- | --- |
| Specimen en español | cursiva + comillas | "*Hablo español*" |
| Specimen en inglés | solo comillas | "I speak Spanish" |
| Palabra nombrada por su función | solo cursiva | *María* is the subject |
| Término técnico, primera vez | negrita | **Syntax** is the layer... |

- La puntuación va **fuera** de las comillas.
- Dentro de las tablas no se usan comillas, solo cursiva.
- La negrita no se usa para specimens (ya tiene dos trabajos: término técnico y frase que nombra el error).
- Sin subrayado nunca (en web el subrayado significa enlace).

---

## Puntuación entre ideas

El punto y seguido corta: úsalo cuando quieras que el lector se detenga, no por defecto. Si dos frases cortas forman una sola idea, únelas: con coma si son paralelas, con dos puntos si la segunda explica o remata la primera. Regla práctica: si tres o cuatro frases seguidas caben en dos renglones cada una, el párrafo está picado; une al menos un par. Esto no contradice "frases cortas": la frase sigue corta, lo que cambia es que las ideas hermanas viajan juntas.

---

## Bloque de metadatos (va al principio del .md, nunca en el cuerpo publicado)

```
Título:          [Tema]: [Promesa concreta]
                 Ej: Spanish Morphology: How Words Are Built
Slug:            spanish-[tema]
Categoría:       [Pilar] + subcategoría propia
Focus keyphrase: Spanish [tema]
SEO title:       Spanish [Tema]: [Promesa] | Spanish Hobby   (máx. 60 caracteres)
Meta desc:       [Los tres elementos concretos]: [qué explica]. [Ubicación en el mapa].
                 Objetivo ~120 caracteres. No pasar de 140. Incluye el pilar por nombre.
Imagen:          Spanish-[Tema].jpg
```

La focus keyphrase aparece sola en título, slug y alt de imagen por cómo está construida la plantilla; no hace falta forzarla en otro sitio.

---

## Mínimos SEO (Yoast)

La frase clave exacta debe aparecer, con naturalidad, en tres lugares:
- La meta description
- El primer párrafo del artículo
- Al menos un encabezado H2

No perseguir "keyphrase density" ni "keyphrase distribution": repetir la frase 6 veces rompe la prosa, que es un diferenciador de la marca. Los puntos rojos de density y distribution se ignoran a propósito.

---

## Checklist final (antes de dar el artículo por terminado)

- [ ] Abre con un ejemplo, no con una definición
- [ ] El concepto se ubica en el mapa en los tres primeros párrafos
- [ ] Usa la terminología técnica real, explicada en inglés llano
- [ ] Al menos dos tablas
- [ ] Al menos un puente explícito hacia otra capa del mapa
- [ ] Sección de errores de angloparlantes, con errores reales
- [ ] Mini-práctica sin solucionario
- [ ] Cierra ubicando el tema en el mapa
- [ ] Todo el español en cursiva
- [ ] Cada specimen entre comillas, dentro y fuera del español
- [ ] Ningún párrafo picado en frases sueltas que son una sola idea
- [ ] Cero emojis, cero rayas, cero subrayados, cero relleno
- [ ] Bloque de metadatos completo, meta description por debajo de 140 caracteres (objetivo ~120)
- [ ] Entre 1.200 y 1.600 palabras

---

## Al terminar

Entrega el artículo completo, listo para que Anya lo apruebe, con su bloque de metadatos arriba.
Recuerda que **publicar es un paso aparte**: se hace en Claude Code siguiendo `plantilla-tecnica.md`. Esta skill solo escribe; no publica.
